public class PrimitiveOperations {
    public static void main(String[] args) {
        int a = 1;
        double b = 1.5;
        System.out.println(a);
        System.out.println(b);
        double product = a*b;
        System.out.println(product);
        double c = (double) a;
        System.out.println(c);
        int d = (int) b;
        System.out.println(d);
        char e = 'A';
        e = (char) (e+32);
        System.out.println(e);
    }
}
